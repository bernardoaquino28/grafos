
# Codigo de grafos

segue e compartilha, se for para colar na cara de pau pelo menos melhora o codigo ou muda as variaveis. ou melhor ainda faz um pix para o dono do git
